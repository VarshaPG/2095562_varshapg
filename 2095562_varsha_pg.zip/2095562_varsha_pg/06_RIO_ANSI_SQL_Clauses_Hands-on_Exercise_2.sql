select s.reg_number, s.student_name,  r.gpa
from student_info s, student_result r
order by r.gpa desc;


select student_name,reg_number,branch,contact_number,Date_of_Birth,Date_of_Joining,address,Email_id from student_info 
order by student_name asc;


select student_name,reg_number,branch,contact_number,Date_of_Birth,Date_of_Joining,address,Email_id from student_info 
order by Date_of_Birth asc;


select s.reg_number, s.student_name, r.sem_num,r.gpa
from student_info s, student_result r
order by r.gpa desc;


select s.reg_number, s.student_name,r.gpa,r.scholarship
from student_info s, student_result r
order by r.Scholarship not like '%Y' ;



select s.reg_number, s.student_name,s.branch,max(r.gpa),r.Sem_num
from student_info s, student_result r
group by r.gpa;


select reg_number, max(gpa),Sem_num
from student_result 
group by Sem_num;


select reg_number, min(gpa),Sem_num
from student_result 
group by sem_num;

