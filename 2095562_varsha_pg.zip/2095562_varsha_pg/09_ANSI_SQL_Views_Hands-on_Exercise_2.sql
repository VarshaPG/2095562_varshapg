use day1_;

create view student_gpa as select s.reg_number, s.student_name , r.gpa, r.sem_num
from student_info s join student_result r
where s.reg_number=r.reg_number;


select   student_name, reg_number, sem_num, gpa from student_gpa
where gpa>5;


create view student_avg_gpa as select s.reg_number, s.student_name , r.gpa, r.sem_num
from student_info s join student_result r
where (select avg(r.gpa) from student_result r);


select reg_number, student_name, sem_num, avg(gpa)
from student_avg_gpa 
where gpa>7;

create index index_student_marks on student_marks(semester);

alter table student_marks drop index index_student_marks;

create unique index unindex_status on student_info(email_id);



