create database day1_;
use day1_;
create table Stu_info(regn varchar(20),sname varchar(30),branch varchar(20),con varchar(20),dob date,doj date,addr varchar(250),eid varchar(250));
create table Sub_info(subcode varchar(20),subname varchar(30),sweight int);
create table  Smarks(sno int,subcode varchar(20), smark int);
alter table Smarks add column regn varchar(20);
create table result(regn varchar(20),sno int, cgpa float, sch varchar(10));
use day1_;
insert into student_info values('MC101301', 'James', 'MCA',' 9714589787', '1984-01-12','2010-07-08' ,'No 10,South Block,Nivea',' james.mca@yahoo.com'),
('BEC111402',' Manio ','ECE',' 8912457875', '1983-02-23', '2011-01-25', '8/12,Park View,Sieera',' manioma@gmail.com'),
('BEEI101204',' Mike',' EI',' 8974567897', '1983-02-10', '2010-08-25 ','Cross villa,NY' ,'mike.james@ymail.com'),
('MB111305', 'Paulson', 'MBA', '8547986123', '1984-12-13', '2010-08-08', 'Lake view,NJ ','paul.son@rediffmail.com');
insert into subject_master values('EE01DCF', 'DCF', 30),('EC02MUP','Microprocessor', 40),
('MC06DIP','DigitalImageP', 30),('MB03MAR','MarketingT', 20),
('EI05IP','InstrumentationP', 40),('CPSC02DS','DataS', 40);
insert into student_marks values('MC101301', 'EE01DCF', 1 ,75),
('MC101301', 'EC02MUP', 1, 65),('MC101301', 'MC06DIP', 1, 70),
('BEC111402', 'EE01DCF', 1,55),('BEC111402', 'EC02MUP', 1 ,80),
('BEC111402', 'MC06DIP', 1, 60),('BEEI101204','EE01DCF', 1, 85),
('BEEI101204', 'EC02MUP', 1,78),('BEEI101204', 'MC06DIP', 1, 80),
('BEEI101204', 'MB03MAR', 2,75),('BEEI101204', 'EI05IP' ,2, 65),
('BEEI101204', 'CPSC02DS', 2, 75),('MB111305', 'EE01DCF', 1, 65),
('MB111305', 'EC02MUP', 1, 68),('MB111305', 'MC06DIP' ,1 ,63),
('MB111305', 'MB03MAR', 2, 85),('MB111305' ,'EI05IP' ,2, 74),('MB111305','CPSC02DS', 2, 62);
insert into student_result values('MC101301', 1, 7.5, 'Y'),('BEC111402', 1, 7.1 ,'Y'),
('BEEI101204',1, 8.3,'Y'),('BEEI101204', 2 ,6.9, 'N'),('MB111305', 1, 6.5, 'N'),('MB111305', 2 ,6.8 ,'N');