use day1_;

select s.reg_number,s.student_name,m.reg_number,m.subject_code,m.marks
from student_info s inner join student_marks m
on s.Reg_Number=m.Reg_Number;


select s.reg_number,s.student_name,m.reg_number,m.subject_code,m.marks
from student_info s inner join student_marks m
on s.Reg_Number=m.Reg_Number
where m.Marks>=65;


select s.reg_number,s.student_name,r.reg_number,max(r.gpa)
from student_info s inner join student_result r
on s.Reg_Number=r.Reg_Number
where r.gpa;


create table backup_sinfo(Reg_number varchar(20) primary key, Student_Name Varchar(30) not null,
Branch Varchar(20),Contact_Number Varchar(20),Date_of_Birth Date not null,
 Date_of_Joining Date , Address Varchar(250), Email_id Varchar(250));
 
 insert into backup_sinfo values('MC101301', 'James', 'MCA',' 9714589787', '1984-01-12','2010-07-08' ,'No 10,South Block,Nivea',' james.mca@yahoo.com'),
('BEC111402',' Manio ','ECE',' 8912457875', '1983-02-23', '2011-01-25', '8/12,Park View,Sieera',' manioma@gmail.com'),
('BEEI101204',' Mike',' EI',' 8974567897', '1983-02-10', '2010-08-25 ','Cross villa,NY' ,'mike.james@ymail.com'),
('MB111305', 'Paulson', 'MBA', '8547986123', '1984-12-13', '2010-08-08', 'Lake view,NJ ','paul.son@rediffmail.com');

insert into student_info values('MC101','Jam','MA','971458787','1984-01-22','2010-07-07' ,'Block,Nivea','s.mca@yahoo.com',5),
('BEC11','nia ','EC',' 8912457878', '1983-02-13', '2011-01-05', 'Park View,Sieera','nia@gmail.com',7),
('BEEI','Mik','rEI',' 8974567197', '1983-02-17', '2010-08-05 ','villa,NY' ,'miks@ymail.com',7),
('MB11', 'Paul', 'MbA', '8547986193', '1984-12-03', '2010-08-18', 'LakeNJ ','paul@rediffmail.com',7);


select s.reg_number,s.student_name,s.branch,s.Contact_Number,s.Date_of_Birth,s.Date_of_Joining,s.address,s.Email_id,
m.reg_number,m.student_name,m.branch,m.Contact_Number,m.Date_of_Birth,m.Date_of_Joining,m.address,m.Email_id
from student_info s right outer join backup_sinfo m
on s.Reg_Number=m.Reg_Number;

select s.reg_number,s.student_name,s.branch,s.Contact_Number,s.Date_of_Birth,s.Date_of_Joining,s.address,s.Email_id,
m.reg_number,m.student_name,m.branch,m.Contact_Number,m.Date_of_Birth,m.Date_of_Joining,m.address,m.Email_id
from student_info s left outer join backup_sinfo m
on s.Reg_Number=m.Reg_Number;