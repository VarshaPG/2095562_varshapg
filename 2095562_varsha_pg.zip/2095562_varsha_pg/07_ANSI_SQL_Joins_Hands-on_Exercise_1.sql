use day1;
select t.tid,b.bid
from trainer_info t cross join batch_info b;


select a.aid , a.mid, a.sdate, a.edate, a.bid ,a.tid,  b.bid
from associate_status a inner join batch_info b
on a.bid=b.bid;



select a.aid, a.tid  
from associate_status a right outer join trainer_info t
on a.tid=t.tid;


select a.aid, a.tid  
from associate_status a left outer join trainer_info t
on a.tid=t.tid;

use day1_;
create table Trainer_info(Tid varchar(20), sal varchar(7), Tname varchar(30));

create table Associate_status(Aid varchar(20),Mid varchar(20),Tid varchar(20));

insert into trainer_info values('F001','Mr.','PANKAJ GHOSH'),('F002','Mr.','SANJAY RADHAKRISHNAN' ),
('F003','Mr.','VIJAY MATHUR'),('F004','Mrs.','NANDINI NAIR');

insert into associate_status values('A001','B001','F001'),('A002','B001','F001'),('A001','B002','F002');

insert into associate_status(Aid,Mid) values('A001','J2SE'),('A002','J2EE');

select a.aid, a.tid  
from associate_status a right outer join trainer_info t
on a.tid=t.tid;

select a.aid, a.tid  
from associate_status a left outer join trainer_info t
on a.tid=t.tid;
