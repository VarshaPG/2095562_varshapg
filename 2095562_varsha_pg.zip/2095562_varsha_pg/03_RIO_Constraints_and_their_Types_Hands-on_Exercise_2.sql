alter table user_ 
drop foreign key fk_us_Pid;




create table S_info(Regnum varchar(20) primary key,
Stu_name varchar(30) not null,
Branch varchar(30),
Con_num varchar(30),
Date_ob varchar(20),
Date_oj varchar(20));

create table Sub_Master ( sub_code varchar(20) primary key,
Sub_name varchar(20) not null,
Weight int not null);


create table Sub_marks( Regnum varchar(20),
constraint fk_Regnum
foreign key(Regnum) references S_info(Regnum),
sub_code varchar(20),
constraint fk_sub_code
foreign key(sub_code) references Sub_Master(sub_code),
sem int not null,
marks int );

create table S_results(Regnum varchar(20),
constraint fk_S_Regnum
foreign key(Regnum) references S_info(Regnum),
sem int not null,
GPA int not null,
Scholarship varchar(3));

alter table Sub_Master modify Sub_Name varchar(20) not null unique;
insert into sub_master values('abc','maths',3),('efg','m',6);


alter table S_info modify Con_num varchar(30) unique;

alter table S_info add check (date_ob < date_oj);

alter table Sub_marks add check (Marks<=100);

alter table s_results add check (GPA<=10);

alter table s_results add check (Scholarship='Y' or Scholarship='N');




