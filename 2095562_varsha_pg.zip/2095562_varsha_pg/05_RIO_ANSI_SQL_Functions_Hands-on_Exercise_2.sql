use day1_;

select upper(concat(Student_name,branch)) from student_info;

select lower(concat(subject_code, subject_name, weightage)) from subject_master;


select date_format(date_of_birth,'%d/%m/%Y') from student_info;

select date_format(date_of_birth,'%M %d,%Y') from student_info;



-- 4:  Write a query to display age of each student along with name, contact number and email id.
   -- Age = Number of months between DOB and current date /12.


select * from student_info;
alter table student_info add age int;
select Student_name, contact_number, email_id, age from student_info 
where age= DATEDIFF(current_date(),date_of_birth);
select *from student_info;


select reg_number ,max(marks) from student_marks;


select concat('The Base Fees Amount for the module name',module_info.Mname, cast(module_info.minfees as decimal)) from module_info;


