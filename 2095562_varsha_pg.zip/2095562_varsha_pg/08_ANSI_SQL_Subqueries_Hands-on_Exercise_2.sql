use day1_;
 
 
select s.reg_number ,s.student_name from student_info s inner join student_marks m on s.reg_number=m.reg_number
where m.marks in(select max(marks) from student_marks m);

select s.reg_number ,s.student_name from student_info s inner join student_marks m on s.reg_number=m.reg_number
where m.marks in(select max(marks) from student_marks m where m.subject_code='EI05IP');

select s.reg_number ,s.student_name from student_info s inner join student_marks m on s.reg_number=m.reg_number
where  (m.marks = (select marks from student_marks as m where subject_code='EI05IP'order by marks desc limit 1,1)and subject_code='EI05IP');

select reg_number from student_marks
where marks> (select avg(marks) from student_marks where subject_code='EI05IP');

