use day1;
select * from associate_info where aname in (select aname from associate_info  where aname  like '%i%');

select * from associate_info where aname in (select aname from associate_info  where aname not like '%i%');


select tid  from associate_status
where Mid in (select Mid from associate_status  WHERE Mid='J2EE');

CREATE TABLE Trainer_Info_Sabbatical(
Trainer_Id VARCHAR(20) PRIMARY KEY,
Salutation VARCHAR(7) NOT NULL,
Trainer_Name VARCHAR(30) NOT NULL,
Trainer_Location VARCHAR(30) NOT NULL,
Trainer_Track VARCHAR(15) NOT NULL,
Trainer_Qualification VARCHAR(100) NOT NULL,
Trainer_Experiance int ,
Trainer_Email VARCHAR(100) NOT NULL,
Trainer_Password VARCHAR(20) NOT NULL);


insert into Trainer_Info_Sabbatical values
 ('F011','Mr.','Shyju K', 'Kochi','Java','Bachelor of Technology',9,'shyju@alliance.com','fac11@123');

insert into Trainer_Info_Sabbatical values
 ('F012','Mr.','Raviraj Kumar', 'Kochi','Java','Bachelor of Technology',8,'raviarajkumar@alliance.com','fac12@123');

insert into Trainer_Info_Sabbatical values 
('F013','Mr.','Suresh Babu N', 'Mumbai','Testing','Bachelor of Technology',19,'sureshbabun@alliance.com','fac13@123');

update Trainer_Info_Sabbatical set Trainer_Location='Kochi' where Trainer_Experiance in 
(select Trainer_Experiance from Trainer_Info_Sabbatical where Trainer_Experiance>10);

delete from Trainer_Info_Sabbatical where Trainer_Experiance in 
(select Trainer_Experiance from Trainer_Info_Sabbatical where Trainer_Experiance>12);


