use day1;
select Temail from Trainer_info where Temail not like '%@%';

select Tid, Tname, Ttrack, Tloc from Trainer_info where Texp>4;

select Mid, Mname from Module_info where Mdur>200;

select Tid, Tname from Trainer_info where Tqua not  in ('BachelorTechnology');

select Mname, Mid from Module_info where Mdur between 200 and 300;

select Tid, Tname from Trainer_info where Tname like 'm%';

select Tid, Tname from Trainer_info where substring_index( Tname, " ", 1) like '%o%';

select Mname from Module_info where  Mname is not null;



use day1_;

select Reg_Number, Student_name from Student_info where Email_id is not null;

select Reg_Number, Marks from Student_marks where Marks>50;

select
Reg_Number,Student_name from Student_info 
union 
select 
subject_code, subject_name from subject_master
union 
select 
semester,marks from Student_marks;


select 
Reg_Number,Student_name from Student_info
union 
select 
subject_code, subject_name from subject_master
union
select
semester, marks from student_marks where marks>50;


select
Reg_Number, GPA, scholarship from student_result   order by gpa desc;

select 
reg_number, student_name from student_info 
union
select
marks from student_marks
union
select
weightage from subject_master;



select student_name from student_info where student_name like ' %';


select
reg_number, student_name,email_id from student_info where email_id is not null
union
select
reg_number,semester, marks from student_marks ;


select 
reg_number, student_name,''  from  student_info
union 
select
reg_number, '',marks from student_marks where marks between 60 and 100;


select reg_number, student_name from  student_info where student_name not like 'j%';




select  student_name from  student_info where student_name like '%on';










