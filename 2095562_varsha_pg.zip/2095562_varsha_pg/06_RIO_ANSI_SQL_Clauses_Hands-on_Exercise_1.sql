use day1;
select sum(Mid),sdate 
from associate_status
group by sdate;

select sum(Mid),sdate 
from associate_status
where Mid='clr'
group by sdate;


select sum(aid),sdate 
from associate_status
where aid='clr'
group by sdate;

select Mid,mname, mdur, minfees
from module_info
order by mdur;

select a.aname, m.mid, m.mname, m.minfees
from associate_info a, module_info m
order by m.minfees desc;

