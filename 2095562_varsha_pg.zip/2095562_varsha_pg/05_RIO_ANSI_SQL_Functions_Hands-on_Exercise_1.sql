use day1;

select module_info.mname,
ROUND ((Minfees),2)
from module_info;


select concat(upper(left(mname,1)),
lower(substring(mname,2)))
from  module_info;

select Mid,
to_days(current_date)-to_days(Sdate)
from associate_status;


select concat(Mname, Mid)
from module_info;


select upper(mname) 
from module_info;

select substr(Mname,1,3)
from module_info;


select (round(avg(ifnull(minfees,0)),3))
from module_info;


select 100000+cast(Tid as decimal)
from trainer_info;

select concat('The Minfees amount for the Mname is',
cinfo.Mname,cast(feesinfo.Minfees as decimal))
from module_info cinfo,Minfees feesinfo
where cinfo.Mid=feesinfo.Mid;

select count(*)
from module_info;

select sum(Minfees)
from module_info;


select min(Minfees),max(Minfees)
from module_info;






