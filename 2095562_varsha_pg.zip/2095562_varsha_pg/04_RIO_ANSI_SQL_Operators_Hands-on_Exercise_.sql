use day1_;

select* from student_info;

select reg_number,sname,branch,con,dob,doj,address from student_info where email is not null;

select reg_nmber,marks from student_marks where marks>50;

select reg_number,sname from student_info union
select
subject_code ,subject_name from Subject_Master union
select sem_no ,marks_no from stu_marks where marks_no>50;
select regno,cgpa,scholarship from stu_result order by gpa desc;
select regno,sname from stu_info union
select marks_no from stu_marks union
select weightage_number from Subject_master;
use day12;
select* from stu_info;
select sname from stu_info where sname like'M%' order by sname;
select sname,regno from stu_info where email is not null
union
select sem_no,marks_no from stu_marks ;
select sname from stu_info where sname like '%on' order by sname; /*problem12*/